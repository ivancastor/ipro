/**
 * iPro — GTM + GA4 + Google Ads (Fase 15 + Landing)
 * Container: GTM-5XGDNMPT | GA4: G-2ZJE5GRPX3 | Ads: AW-17817579491
 */
(function () {
  "use strict";

  if (window.__iproGtmLoaded) return;
  window.__iproGtmLoaded = true;

  window.dataLayer = window.dataLayer || [];

  var GTM_ID = "GTM-5XGDNMPT";
  var GA4_ID = "G-2ZJE5GRPX3";
  var ADS_ID = "AW-17817579491";
  var ATTRIBUTION_KEYS = [
    "gclid",
    "gbraid",
    "wbraid",
    "gad_source",
    "utm_source",
    "utm_medium",
    "utm_campaign",
    "utm_term",
    "utm_content",
    "utm_id",
    "campaignid",
    "adgroupid",
    "keyword",
  ];
  var AGENDAR_TEXTS = [
    "agendar",
    "agendar agora",
    "iniciar agendamento",
    "solicitar agendamento",
    "fazer agendamento",
  ];
  var STORAGE_KEY = "ipro_attribution_v1";

  var _agendamentoFired = false;

  function push(event, params) {
    var payload = Object.assign({ event: event }, params || {});
    window.dataLayer.push(payload);
    if (window.console && window.location.search.indexOf("gtm_debug=1") > -1) {
      console.log("[iPro GTM]", payload);
    }
  }

  function getLandingSlug() {
    var meta = document.querySelector('meta[name="ipro-landing-slug"]');
    if (meta && meta.content) return meta.content;
    var path = window.location.pathname || "";
    return path.replace(/^\//, "").replace(/\.html$/, "") || "unknown";
  }

  function readStoredAttribution() {
    try {
      var raw = sessionStorage.getItem(STORAGE_KEY);
      return raw ? JSON.parse(raw) : {};
    } catch (e) {
      return {};
    }
  }

  function writeStoredAttribution(data) {
    try {
      sessionStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {}
  }

  function captureAttribution() {
    var params = new URLSearchParams(window.location.search);
    var stored = readStoredAttribution();
    var updated = false;

    ATTRIBUTION_KEYS.forEach(function (key) {
      var value = params.get(key);
      if (value) {
        stored[key] = value;
        updated = true;
      }
    });

    if (updated || !stored.landing_page) {
      stored.landing_page = getLandingSlug();
      stored.landing_url = window.location.href;
      stored.landing_path = window.location.pathname;
      stored.captured_at = new Date().toISOString();
      writeStoredAttribution(stored);
    }

    return stored;
  }

  function attributionPayload() {
    var attr = captureAttribution();
    var payload = {
      landing_page: attr.landing_page || getLandingSlug(),
      page_location: window.location.href,
      page_path: window.location.pathname,
      page_title: document.title,
    };

    ATTRIBUTION_KEYS.forEach(function (key) {
      if (attr[key]) payload[key] = attr[key];
    });

    return payload;
  }

  function buildAgendamentoUrl(href, section, service) {
    try {
      var url = new URL(href, window.location.origin);
      var attr = captureAttribution();

      url.searchParams.set("ref", getLandingSlug());
      if (section) url.searchParams.set("sec", section);
      if (service) url.searchParams.set("svc", service);

      ATTRIBUTION_KEYS.forEach(function (key) {
        if (attr[key] && !url.searchParams.has(key)) {
          url.searchParams.set(key, attr[key]);
        }
      });

      return url.toString();
    } catch (e) {
      return href;
    }
  }

  function decorateAgendarLinks() {
    document.querySelectorAll('a[href*="agendamento"]').forEach(function (link) {
      var section = link.getAttribute("data-ipro-section") || inferSection(link);
      var service = link.getAttribute("data-ipro-service") || "";
      var href = link.getAttribute("href") || "";
      if (!href || href.indexOf("agendamento") === -1) return;
      link.setAttribute("href", buildAgendamentoUrl(href.split("?")[0], section, service));
    });
  }

  function inferSection(el) {
    var node = el.closest("section[id], footer, header");
    if (!node) return "page";
    if (node.id) return node.id;
    if (node.tagName === "FOOTER") return "footer";
    if (node.tagName === "HEADER") return "header";
    return "page";
  }

  function getClickContext(target) {
    return {
      click_text: (target.getAttribute("data-ipro-label") || target.textContent || "").trim(),
      link_url: target.getAttribute("href") || "",
      page_section: target.getAttribute("data-ipro-section") || inferSection(target),
      service_name: target.getAttribute("data-ipro-service") || "",
      cta_type: target.getAttribute("data-ipro-cta") || "",
      landing_page: getLandingSlug(),
    };
  }

  function mergeAttribution(params) {
    return Object.assign({}, attributionPayload(), params || {});
  }

  function fireAgendamentoConcluido(data) {
    if (_agendamentoFired) return;
    _agendamentoFired = true;
    push("agendamento_concluido", mergeAttribution(Object.assign({ currency: "BRL", value: 0 }, data || {})));
  }

  function pushLandingPageView() {
    push("landing_page_view", mergeAttribution({
      event_category: "landing",
      event_label: getLandingSlug(),
    }));
  }

  window.iproTrack = {
    agendamentoConcluido: fireAgendamentoConcluido,
    cliqueWhatsapp: function (url, ctx) {
      push("clique_whatsapp", mergeAttribution(Object.assign({ link_url: url || "" }, ctx || {})));
    },
    cliqueTelefone: function (url, ctx) {
      push("clique_telefone", mergeAttribution(Object.assign({ link_url: url || "" }, ctx || {})));
    },
    cliqueAgendar: function (url, text, ctx) {
      push("clique_agendar", mergeAttribution(Object.assign({
        link_url: url || "",
        click_text: text || "",
      }, ctx || {})));
    },
    cliqueMaps: function (url, ctx) {
      push("clique_maps", mergeAttribution(Object.assign({ link_url: url || "" }, ctx || {})));
    },
    cliqueVerServicos: function (url, ctx) {
      push("clique_ver_servicos", mergeAttribution(Object.assign({ link_url: url || "" }, ctx || {})));
    },
  };

  function matchesAgendarText(text) {
    var t = (text || "").toLowerCase().replace(/\s+/g, " ").trim();
    for (var i = 0; i < AGENDAR_TEXTS.length; i++) {
      if (t.indexOf(AGENDAR_TEXTS[i]) > -1) return true;
    }
    return false;
  }

  function isMapsUrl(href) {
    return /google\.com\/maps|maps\.google|goo\.gl\/maps/i.test(href || "");
  }

  document.addEventListener(
    "click",
    function (e) {
      var target = e.target.closest("a, button");
      if (!target) return;

      var href = target.getAttribute("href") || "";
      var text = (target.textContent || "").trim();
      var ctx = getClickContext(target);
      var cta = target.getAttribute("data-ipro-cta") || "";

      if (
        href.indexOf("wa.me") > -1 ||
        href.indexOf("api.whatsapp.com") > -1 ||
        href.indexOf("whatsapp.com") > -1
      ) {
        window.iproTrack.cliqueWhatsapp(href, ctx);
        return;
      }

      if (href.indexOf("tel:") === 0) {
        window.iproTrack.cliqueTelefone(href, ctx);
        return;
      }

      if (isMapsUrl(href)) {
        window.iproTrack.cliqueMaps(href, ctx);
        return;
      }

      if (cta === "ver_servicos" || (href.charAt(0) === "#" && /ver servi/i.test(text))) {
        window.iproTrack.cliqueVerServicos(href, ctx);
        return;
      }

      if (cta === "agendar" || matchesAgendarText(text) || href.indexOf("agendamento") > -1) {
        if (href.indexOf("agendamento") > -1) {
          var decorated = buildAgendamentoUrl(href.split("?")[0], ctx.page_section, ctx.service_name);
          target.setAttribute("href", decorated);
          ctx.link_url = decorated;
        }
        window.iproTrack.cliqueAgendar(ctx.link_url || href, ctx.click_text || text, ctx);
      }
    },
    true
  );

  function overlayIsSuccess(el) {
    if (!el || !el.classList.contains("terms-open")) return false;
    var box = document.getElementById("agend-terms-box");
    if (!box) return false;
    return box.textContent.indexOf("Solicitação enviada") > -1;
  }

  function watchAgendamentoSuccess() {
    var termsOvl = document.getElementById("agend-terms-overlay");
    if (termsOvl) {
      var termsObs = new MutationObserver(function () {
        if (overlayIsSuccess(termsOvl)) {
          fireAgendamentoConcluido({ conversion_source: "agendamento_overlay" });
        }
      });
      termsObs.observe(termsOvl, { attributes: true, attributeFilter: ["class"], subtree: true, childList: true });
    }

    var pixSuccess = document.getElementById("agend-pix-success");
    if (pixSuccess) {
      var pixObs = new MutationObserver(function () {
        if (pixSuccess.style.display === "block") {
          fireAgendamentoConcluido({ conversion_source: "pix_pago", value: 0 });
        }
      });
      pixObs.observe(pixSuccess, { attributes: true, attributeFilter: ["style"] });
    }
  }

  function initLandingTracking() {
    captureAttribution();
    decorateAgendarLinks();
    pushLandingPageView();
    watchAgendamentoSuccess();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", initLandingTracking);
  } else {
    initLandingTracking();
  }
  setTimeout(initLandingTracking, 500);

  window.IPRO_GTM_ID = GTM_ID;
  window.IPRO_GA4_ID = GA4_ID;
  window.IPRO_ADS_ID = ADS_ID;
})();
